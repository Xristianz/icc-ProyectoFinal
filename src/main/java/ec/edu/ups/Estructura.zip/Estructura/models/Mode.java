package ec.edu.ups.controlador;

public enum Mode {
    START, END, WALL;
}
